﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Http;
using System.Security.Cryptography;
using System.Security.Principal;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.Design;
using Newtonsoft.Json;

namespace CateringReservation
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        public class LoginResponse
        {
            public string Message { get; set; }
        }

        private static readonly HttpClient client = new HttpClient();
        private string baseURL = "http://localhost:3000/acc"; // Replace with your API base URL

        public async Task<LoginResponse> Login(string username, string password)
        {
            try
            {
                var payload = new { username, password };
                var content = new StringContent(JsonConvert.SerializeObject(payload), Encoding.UTF8, "application/json");

                HttpResponseMessage response = await client.PostAsync($"{baseURL}/login", content);

                if (response.IsSuccessStatusCode)
                {
                    string responseBody = await response.Content.ReadAsStringAsync();
                    LoginResponse loginResponse = JsonConvert.DeserializeObject<LoginResponse>(responseBody);
                    return loginResponse;
                }
                else
                {
                    // Handle error response
                    Console.WriteLine($"Failed to authenticate. Status code: {response.StatusCode}");
                    return null;
                }
            }
            catch (Exception ex)
            {
                // Handle exception
                Console.WriteLine($"An error occurred: {ex.Message}");
                return null;
            }
        }

        private async void Loginbtn_Click(object sender, EventArgs e)
        {
            string username = UnameTb.Text;
            string password = UPassTb.Text;

            LoginResponse loginResponse = await Login(username, password);

            if (loginResponse != null && loginResponse.Message == "Login successful")
            {
                //MessageBox.Show("Login successful");
                Mainform mf = new Mainform();
                this.Hide();
                mf.Show();
                // 8c6976e5b5410415bde908bd4dee15dfb167a9c873fc4bb8a81f6f2ab448a918

            }
            else
            {
               MessageBox.Show("Failed to login");
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
