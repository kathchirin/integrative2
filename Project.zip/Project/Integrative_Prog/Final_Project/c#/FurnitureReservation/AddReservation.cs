﻿using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CateringReservation
{
    public partial class AddReservation : Form
    {
        public AddReservation()
        {
            InitializeComponent();
        }

        private static readonly HttpClient client = new HttpClient();

        private void BtnBack_Click(object sender, EventArgs e)
        {
            Mainform mf = new Mainform();
            this.Hide();
            mf.Show();
        }
        bool number = false;

        public void testingP()
        {

            int desiredLength = 11;

            if (TbxContact.Text.Length != desiredLength)
            {
                number = true;
            }
            else
            {
                number = false;
            }
        }

        private void AddReservation_Load(object sender, EventArgs e)
        {
            LblId.Visible = false;

            if(Data.checker == true)
            {
                LblId.Text = Data.id.ToString();

                BtnAdd.Visible = false;
                BtnDelete.Visible = true;
                BtnUpdate.Visible = true;

                TbxFname.Text = Data.fname;
                TbxMname.Text = Data.mname;
                TbxLname.Text = Data.lname;
                TbxContact.Text = Data.contact;
                TbxAddress.Text = Data.address;
                CbxFur.Text = Data.furniture;
                TbxAge.Text = Data.age.ToString();
                DtpDate.Text = Data.date;

            }
            else
            {
                BtnDelete.Visible = false;
                BtnUpdate.Visible = false;
                Reset();
            }
        }

        public class Client
        {
            public string firstname { get; set; }
            public string middlename { get; set; }
            public string lastname { get; set; }
            public string contact { get; set; }
            public string address { get; set; }
            public string furniture { get; set; }
            public int age { get; set; }
            public string datereserved { get; set; }
        }

        static async Task AddClientAsync( Client clients)
        {
            try
            {
                var client = new HttpClient();
                var uri = "http://localhost:3000/cli/clients"; 
               

                var json = JsonConvert.SerializeObject(clients);
                var content = new StringContent(json, System.Text.Encoding.UTF8, "application/json");

                var response = await client.PostAsync(uri, content);
                response.EnsureSuccessStatusCode();

                var responseBody = await response.Content.ReadAsStringAsync();
                var result = JsonConvert.DeserializeObject<dynamic>(responseBody);

                Console.WriteLine(result.message);
            }
            catch (HttpRequestException e)
            {
                Console.WriteLine($"Request exception: {e.Message}");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Exception: {ex.Message}");
            }
        }

        private async void BtnAdd_Click(object sender, EventArgs e)
        {
            testingP();
            if (number == true)
            {
                number = false;
                MessageBox.Show("Invalid Phone Number", "Invalid", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            } else {
                var clientData = new Client
                {
                    firstname = TbxFname.Text,
                    middlename = TbxMname.Text,
                    lastname = TbxLname.Text,
                    contact = TbxContact.Text,
                    address = TbxAddress.Text,
                    furniture = CbxFur.Text,
                    age = int.Parse(TbxAge.Text),
                    datereserved = DtpDate.Value.ToString("yyyy-MM-dd")
                };

                await AddClientAsync(clientData);
                MessageBox.Show("Save Sucessfully");
                Reset();
            }

        }

        public void Reset()
        {
            TbxFname.Clear();
            TbxMname.Clear();
            TbxLname.Clear();
            TbxContact.Clear();
            TbxAddress.Clear();
            CbxFur.ResetText();
            TbxAge.Clear();
            DtpDate.ResetText();
        }

        private async Task UpdateClientAsync(Client clients,int clientId)
        {
            try
            {
                var json = JsonConvert.SerializeObject(clients);
                var content = new StringContent(json, Encoding.UTF8, "application/json");

                using (HttpClient client = new HttpClient())
                {
                    HttpResponseMessage response = await client.PutAsync($"http://localhost:3000/cli/clients/{clientId}", content);
                    response.EnsureSuccessStatusCode();
                    string responseBody = await response.Content.ReadAsStringAsync();
                    MessageBox.Show("Response from server: " + responseBody);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error updating client: " + ex.Message);
            }
        }


        private async void BtnUpdate_Click(object sender, EventArgs e)
        {
            int clientId = int.Parse(LblId.Text);

            var updatedClient = new Client
            {
                firstname = TbxFname.Text,
                middlename = TbxMname.Text,
                lastname = TbxLname.Text,
                contact = TbxContact.Text,
                address = TbxAddress.Text,
                furniture = CbxFur.Text,
                age = int.Parse(TbxAge.Text),
                datereserved = DtpDate.Value.ToString("yyyy-MM-dd")
            };

            Data.checker = false;

            await UpdateClientAsync(updatedClient, clientId);
            ViewReservation vr = new ViewReservation();
            this.Hide();
            vr.Show();
        }

        private async Task DeleteClientAsync(int clientId)
        {
            try
            {
                using (HttpClient client = new HttpClient())
                {
                    HttpResponseMessage response = await client.DeleteAsync($"http://localhost:3000/cli/clients/{clientId}");
                    response.EnsureSuccessStatusCode();
                    string responseBody = await response.Content.ReadAsStringAsync();
                    MessageBox.Show("Response from server: " + responseBody);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error deleting client: " + ex.Message);
            }
        }

        private async void BtnDelete_Click(object sender, EventArgs e)
        {
            int clientId = int.Parse(LblId.Text);

            await DeleteClientAsync(clientId);

            // Assuming ViewReservation is another form that you want to show
            ViewReservation vr = new ViewReservation();
            this.Hide();
            vr.Show();
        }

        private void TbxAge_KeyPress(object sender, KeyPressEventArgs e)
        {
            char age = e.KeyChar;
            if(!char.IsDigit(age) && age != 8)
            {
                e.Handled = true;
            }
        }

        private void TbxContact_KeyPress(object sender, KeyPressEventArgs e)
        {
            char age = e.KeyChar;
            if (!char.IsDigit(age) && age != 8)
            {
                e.Handled = true;
            }
        }
    }
}
