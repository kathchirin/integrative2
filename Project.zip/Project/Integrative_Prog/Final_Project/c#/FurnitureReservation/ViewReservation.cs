﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CateringReservation
{
    public partial class ViewReservation : Form
    {
        public ViewReservation()
        {
            InitializeComponent();
        }
        private static readonly HttpClient client = new HttpClient();
        private void BtnBack_Click(object sender, EventArgs e)
        {
            Mainform mf = new Mainform();
            this.Hide();
            mf.Show();
        }

        public class Client
        {
            [JsonProperty("client_id")]
            public int Id { get; set; }
            public string Firstname { get; set; }
            public string Middlename { get; set; }
            public string Lastname { get; set; }
            public string Contact { get; set; }
            public string Address { get; set; }
            public string Furniture { get; set; }

            public string Age { get; set; }
            public string DateReserved { get; set; }

        }


        private async Task<List<Client>> GetClientsAsync()
        {
            HttpResponseMessage response = await client.GetAsync("http://localhost:3000/cli/clients");
            response.EnsureSuccessStatusCode();
            string responseBody = await response.Content.ReadAsStringAsync();
            return JsonConvert.DeserializeObject<List<Client>>(responseBody);
        }

        private async void ViewReservation_Load(object sender, EventArgs e)
        {
            try
            {
                var clients = await GetClientsAsync();
                DgvReserve.DataSource = clients;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error fetching clients: " + ex.Message);
            }
        }

        private void DgvReserve_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0 && DgvReserve.Columns[e.ColumnIndex].Name == "Firstname")
            {
                var clientid = int.Parse(DgvReserve.Rows[e.RowIndex].Cells[0].Value.ToString());
                var firstname = DgvReserve.Rows[e.RowIndex].Cells[1].Value.ToString();
                var middlename = DgvReserve.Rows[e.RowIndex].Cells[2].Value.ToString();
                var lastname = DgvReserve.Rows[e.RowIndex].Cells[3].Value.ToString();
                var contact = DgvReserve.Rows[e.RowIndex].Cells[4].Value.ToString();
                var address = DgvReserve.Rows[e.RowIndex].Cells[5].Value.ToString();
                var furniture = DgvReserve.Rows[e.RowIndex].Cells[6].Value.ToString();
                var age = int.Parse(DgvReserve.Rows[e.RowIndex].Cells[7].Value.ToString());
                var date = DgvReserve.Rows[e.RowIndex].Cells[8].Value.ToString();

                try
                {
                    Data.fname = firstname;
                    Data.mname = middlename;
                    Data.lname = lastname;
                    Data.contact = contact;
                    Data.address = address;
                    Data.furniture = furniture;
                    Data.age = age;
                    Data.date = date;
                    Data.id = clientid;

                    Data.checker = true;

                    AddReservation ar = new AddReservation();
                    this.Hide();
                    ar.Show();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("An error occurred: " + ex.Message);
                }
            }
        }
    }
}
