﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CateringReservation
{
    internal class Data
    {
        public static string fname = "";
        public static string mname = "";
        public static string lname = "";
        public static string contact = "";
        public static string address = "";
        public static string furniture = "";
        public static int age = 0;
        public static string date = "";
        public static int id = 0;
        public static bool checker = false;
    }
}
