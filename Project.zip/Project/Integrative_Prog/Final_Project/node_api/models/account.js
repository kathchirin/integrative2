const crypto = require('crypto');
const pool = require('../services/db');

const getAccountByUsernameAndPassword = (username, password) => {
  return new Promise((resolve, reject) => {
    // Hash the password using SHA-256
    const hashedPassword = crypto.createHash('sha256').update(password).digest('hex');

    // Log the hashed password for debugging
    console.log(`Hashed password: ${hashedPassword}`);

    const query = "SELECT * FROM account WHERE username = ? AND password = ?";
    pool.query(query, [username, hashedPassword], (err, results) => {
      if (err) {
        console.error("Error fetching account by username and password:", err);
        reject(err);
      } else {
        resolve(results);
      }
    });
  });
};

module.exports = {
  getAccountByUsernameAndPassword
};
