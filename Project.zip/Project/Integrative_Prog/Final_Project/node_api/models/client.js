const pool = require('../services/db');

const getAllClients = () => {
  return new Promise((resolve, reject) => {
    pool.query("SELECT * FROM client", (err, results) => {
      if (err) {
        console.error("Error fetching all clients", err);
        reject(err);
      } else {
        resolve(results);
      }
    });
  });
};

const addClient = (client) => {
  const { firstname, middlename, lastname, contact, address, furniture, age, datereserved } = client;
  return new Promise((resolve, reject) => {
    const insertQuery = 'INSERT INTO client (firstname, middlename, lastname, contact, address,furniture, age, datereserved) VALUES (?, ?, ?, ?, ?, ?, ?, ?)';
    pool.query(insertQuery, [firstname, middlename, lastname, contact, address, furniture, age, datereserved], (err, results) => {
      if (err) {
        console.error("Error adding client:", err);
        reject(err);
      } else {
        resolve({ message: "Client added successfully" });
      }
    });
  });
};
const updateClient = (clientId, client) => {
  const { firstname, middlename, lastname, contact, address, furniture, age, datereserved } = client;
  return new Promise((resolve, reject) => {
    const updateQuery = 'UPDATE client SET firstname = ?, middlename = ?, lastname = ?, contact = ?, address = ?, furniture = ?, age = ?, datereserved = ? WHERE client_id = ?';
    pool.query(updateQuery, [firstname, middlename, lastname, contact, address, furniture, age, datereserved, clientId], (err, results) => {
      if (err) {
        console.error("Error updating client:", err);
        reject(err);
      } else {
        resolve({ message: "Client updated successfully" });
      }
    });
  });
};

const deleteClient = (clientId) => {
  return new Promise((resolve, reject) => {
    const deleteQuery = 'DELETE FROM client WHERE client_id = ?';
    pool.query(deleteQuery, [clientId], (err, results) => {
      if (err) {
        console.error("Error deleting client:", err);
        reject(err);
      } else {
        resolve({ message: "Client deleted successfully" });
      }
    });
  });
};

module.exports = {
  getAllClients,
  addClient,
  updateClient,
  deleteClient
};
