// index.js
const express = require('express');
const client = require('./routes/clientRoutes');
const accountRoutes = require('./routes/accountRoutes');
const bodyParser = require('body-parser');
const cors = require('cors');

const app = express();
const port = 3000;

app.use(bodyParser.json());
app.use(cors());

// Corrected route setup
app.use('/cli', client);
app.use('/acc', accountRoutes);

app.listen(port, () => {
  console.log(`Server is running on http://localhost:${port}`);
});
