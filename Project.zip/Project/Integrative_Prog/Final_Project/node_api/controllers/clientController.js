const clientModel = require("../models/client");

const getAllClients = async (req, res) => {
  try {
    const clients = await clientModel.getAllClients();
    res.json(clients);
  } catch (error) {
    console.error("Error in getAllClients:", error);
    res.status(500).json({ error: "Internal Server Error" });
  }
};

const addClient = async (req, res) => {
  try {
    await clientModel.addClient(req.body);
    res.status(201).json({ message: "Client added successfully" });
  } catch (error) {
    console.error("Error in addClient:", error);
    res.status(500).json({ error: "Internal Server Error" });
  }
};
const updateClient = async (req, res) => {
  const { clientId } = req.params;
  try {
    const result = await clientModel.updateClient(clientId, req.body);
    res.status(200).json(result);
  } catch (error) {
    console.error("Error in updateClient:", error);
    res.status(500).json({ error: "Internal Server Error" });
  }
};

const deleteClient = async (req, res) => {
  try {
    await clientModel.deleteClient(req.params.clientId);
    res.status(200).json({ message: "Client deleted successfully" });
  } catch (error) {
    console.error("Error in deleteClient:", error);
    res.status(500).json({ error: "Internal Server Error" });
  }
};

module.exports = {
  getAllClients,
  addClient,
  updateClient,
  deleteClient
};
