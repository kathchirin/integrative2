const express = require('express');
const router = express.Router();
const clientController = require('../controllers/clientController');

router.get('/clients', clientController.getAllClients);
router.post('/clients', clientController.addClient);
router.put('/clients/:clientId', clientController.updateClient);
router.delete('/clients/:clientId', clientController.deleteClient);

module.exports = router;
