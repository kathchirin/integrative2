<?php
   include("config/initialize.php");
   

   HTML :: head();
   $current_tab = "dashboard";

   if(isset($_GET['tab']))
   {
    $current_tab = $_GET['tab'];
   }
   HTML :: sidebar($current_tab);
   HTML :: navbar();

   if($current_tab == "allreservation")
   {
      allreserved();
   }

   if($current_tab == "addreservation")
   {
      addreservation();
   }

   if($current_tab == "dashboard")
   {
      dashboard();
   }
?>
