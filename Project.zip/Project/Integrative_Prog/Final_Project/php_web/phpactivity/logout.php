<?php
ob_start(); // Start output buffering
require_once('config/classes/session.php');

session_start();
$session = new Session();
$logoutSuccess = $session->logout();

if ($logoutSuccess) {
    header('Location: index.php'); // Redirect to login page
    exit;
} else {
    echo "Logout failed!";
}
ob_end_flush(); // End output buffering
?>
