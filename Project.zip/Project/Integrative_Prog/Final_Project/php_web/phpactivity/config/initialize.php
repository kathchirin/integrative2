<?php
require_once('classes/database.php');
require_once('classes/session.php');
require_once('config/classes/htmlclass.php');
require_once('Components/pages/allreserved.php');
require_once('Components/pages/addreservation.php');
require_once('Components/pages/dashboard.php');
?>
