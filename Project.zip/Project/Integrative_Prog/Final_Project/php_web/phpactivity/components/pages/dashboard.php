<?php
function dashboard() {
    ?>
    <div class="container-xxl flex-grow-1 container-p-y">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-body">
                        <h1 class="mb-3">Welcome to Our Furniture Business</h1>
                        <p>
                            Our furniture business is built on the belief that a home is a reflection of your personality.
                            We craft high-quality furniture pieces that combine functionality with elegant design. Whether you're
                            furnishing a home, office, or commercial space, our wide range of custom-made tables, chairs, and cabinets
                            is built to suit every need and taste.
                        </p>
                        <p>
                            Established in 2025, our mission has always been to deliver comfort, style, and durability to every household.
                            Each piece we create is made with precision, passion, and premium materials sourced locally.
                        </p>

                        <h5 class="mt-4">Gallery</h5>
                        <div class="row">
                            <div class="col-md-4 mb-4">
                                <img src="assets/img/avatars/chair.png" class="img-fluid rounded" alt="Furniture 1" style="height: 500px; width: 100%; object-fit: cover;">
                                <p class="mt-2 text-center">Modern Wooden Chair</p>
                            </div>
                            <div class="col-md-4 mb-4">
                                <img src="assets/img/avatars/table.png" class="img-fluid rounded" alt="Furniture 2" style="height: 500px; width: 100%; object-fit: cover;">
                                <p class="mt-2 text-center">Classic Dining Table</p>
                            </div>
                            <div class="col-md-4 mb-4">
                                <img src="assets/img/avatars/cabinet.png" class="img-fluid rounded" alt="Furniture 3" style="height: 500px; width: 100%; object-fit: cover;">
                                <p class="mt-2 text-center">Custom Storage Cabinet</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php
}
?>
