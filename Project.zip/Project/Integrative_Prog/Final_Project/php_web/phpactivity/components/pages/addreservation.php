<?php
function addreservation() {
    ?>

    <div class="container-xxl flex-grow-1 container-p-y">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-body">
                        <form id="formAuthentication" class="mb-3">
                            <div class="row">
                                <div class="mb-3 col-md-6">
                                    <label for="title" class="form-label">Firstname</label>
                                    <input class="form-control" type="text" id="fname" name="title" placeholder="Enter Firstname" required />
                                </div>
                                <div class="mb-3 col-md-6">
                                    <label for="category" class="form-label">Middlename</label>
                                    <input class="form-control" type="text" id="mname" name="category" placeholder="Enter Middlename" required />
                                </div>
                                <div class="mb-3 col-md-6">
                                    <label for="description" class="form-label">Lastname</label>
                                    <input class="form-control" type="text" id="lname" name="description" placeholder="Enter Lastname" required />
                                </div>
                                <div class="mb-3 col-md-6">
                                    <label for="author" class="form-label">Contact</label>
                                    <input class="form-control" type="text" id="contact" name="author" placeholder="Enter Contact Number" required />
                                </div>
                                <div class="mb-3 col-md-6">
                                    <label for="publication" class="form-label">Address</label>
                                    <input class="form-control" type="text" id="address" name="publication" placeholder="Enter Address" required />
                                </div>
                                <div class="mb-3 col-md-6">
                                    <label for="furniture" class="form-label">Furniture</label>
                                    <select class="form-control" id="furniture" name="furniture" required>
                                        <option value="" disabled selected>Select Furniture Type</option>
                                        <option value="table">Table</option>
                                        <option value="chair">Chair</option>
                                        <option value="cabinet">Cabinet</option>
                                    </select>
                                </div>
                                <div class="mb-3 col-md-6">
                                    <label for="quantity" class="form-label">Age</label>
                                    <input class="form-control" type="number" id="age" name="quantity" placeholder="Enter your Age" required />
                                </div>
                                <div class="mb-3 col-md-6">
                                    <label for="quantity" class="form-label">Date Reserved</label>
                                    <input class="form-control" type="date" id="date" name="quantity" placeholder="Select Date" required />
                                </div>
                            </div>
                            <button type="submit" class="btn btn-success me-2">Add</button>
                            <button type="reset" class="btn btn-outline-secondary">Cancel</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
    document.getElementById('formAuthentication').addEventListener('submit', function(event) {
        event.preventDefault(); // Prevent default form submission

        // Capture form data
        const firstname = document.getElementById('fname').value;
        const middlename = document.getElementById('mname').value;
        const lastname = document.getElementById('lname').value;
        const contact = document.getElementById('contact').value;
        const address = document.getElementById('address').value;
        const furniture = document.getElementById('furniture').value;
        const age = document.getElementById('age').value;
        const datereserved = document.getElementById('date').value;

        // Construct the book object
        const book = {
            firstname: firstname,
            middlename: middlename,
            lastname: lastname,
            contact: contact,
            address: address,
            furniture: furniture,
            age: age,
            datereserved: datereserved
        };

        // Call the API to add the book
        fetch('http://localhost:3000/cli/clients', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(book)
        })
        .then(response => response.json())
        .then(data => {
            console.log(data); // For debugging purposes
            if (data.success) {
                alert('Book added successfully with ID: ' + data.insertId);
                // Optionally, reset the form or redirect to another page
                document.getElementById('formAuthentication').reset();
            } else {
                document.getElementById('formAuthentication').reset();
            }
        })
        .catch(error => {
            console.error('Error adding book:', error);
            alert('Failed to add book. Please try again.');
        });
    });
    </script>

    <?php
}
?>
