<?php 
function allreserved() {
?>

<div class="container-xxl flex-grow-1 container-p-y">
<h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light">Reserved /</span> All Reserved</h4>

<form method="post" id="workersForm">
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-body">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Reservation Id</th>
                                <th>Name</th>
                                <th>Contact</th>
                                <th>Address</th>
                                <th>Furniture</th>
                                <th>Age</th>
                                <th>Date Reserved</th>
                            </tr>
                        </thead>
                        <tbody id="bookTableBody">
                            <!-- Data will be inserted here dynamically -->
                        </tbody>
                    </table>
                </div>
            </div>
          
        </div>
    </div>
</form>
<br><br>
</div>

<script>
// Fetch data from the API endpoint
fetch('http://localhost:3000/cli/clients')
    .then(response => response.json())
    .then(data => {
        // Render data in the table
        const bookTableBody = document.getElementById('bookTableBody');
        data.forEach(book => {
            const row = `
                <tr>
                    <td>${book.client_id}</td>
                    <td>${book.firstname + " " + book.middlename + " " + book.lastname }</td>
                    <td>${book.contact}</td>
                    <td>${book.address}</td>
                    <td>${book.furniture}</td>
                    <td>${book.age}</td>
                    <td>${book.datereserved}</td>
                </tr>
            `;
            bookTableBody.innerHTML += row;
        });
    })
    .catch(error => console.error('Error fetching books:', error));
</script>

<?php 
}
?>
