<body>
  <!-- Layout wrapper -->
  <div class="layout-wrapper layout-content-navbar">
    <div class="layout-container">
      <!-- Menu -->
      <aside id="layout-menu" class="layout-menu menu-vertical menu bg-menu-theme">
        <div class="app-brand demo">
          <a href="home.php" class="app-brand-link">
            <img src="assets/img/avatars/logo.png" alt class="w-px-50 h-auto rounded-circle" />
            <span class="app-brand-text menu-text fw-bolder ms-2">Furniture Reservation</span>
          </a>

          <a href="javascript:void(0);" class="layout-menu-toggle menu-link text-large ms-auto d-block d-xl-none">
            <i class="bx bx-chevron-left bx-sm align-middle"></i>
          </a>
        </div>

        <div class="menu-inner-shadow"></div>

        <ul class="menu-inner py-1">
          <!-- Dashboard -->
          <li class="menu-item <?php if (isset($current_tab) && $current_tab == 'dashboard'){ echo 'active';} ?>">
            <a href="home.php?tab=dashboard" class="menu-link">
              <img src="assets/img/avatars/dashboard.png" alt class="w-px-40 h-auto" />
              <i class="menu-icon tf-icons bx"></i>
              <div data-i18n="Analytics">Dashboard</div>
            </a>
          </li>

          <li class="menu-item <?php if(isset($current_tab)&& $current_tab == 'allreservation'){ echo 'active open';} ?>">
            <a href="home.php?tab=allreservation" class="menu-link">
              <img src="assets/img/avatars/reservation.png" alt class="w-px-40 h-auto" />
              <div data-i18n="Account Settings">All Reservation</div>
            </a>
          </li>

          <li class="menu-item <?php if(isset($current_tab)&& $current_tab == 'addreservation'){ echo 'active open';} ?>">
            <a href="home.php?tab=addreservation" class="menu-link">
              <img src="assets/img/avatars/add.png" alt class="w-px-40 h-auto" />
              <div data-i18n="Account Settings">Add Reservation</div>
            </a>
          </li>
        </ul>

        <!-- User Icon Logout -->
        <div class="navbar-nav-right d-flex align-items-center px-3 pb-3">
          <ul class="navbar-nav flex-row align-items-center ms-auto">
            <li class="nav-item">
              <a href="index.php" title="Logout" class="btn p-0 border-0 bg-transparent">
                <img src="assets/img/avatars/user.png" alt="User" class="w-px-40 h-auto rounded-circle" />
              </a>
            </li>
          </ul>
        </div>
      </aside>
      <!-- /Menu -->
